package com.cts.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.entities.Customer;
import com.cts.entities.Property;
import com.cts.entities.Requirement;

@Service
public interface CustomerService {

	List<Requirement> getAllRequirements();
	
	List<Customer> getAllCustomers();
	
	void createCustomer(Customer customer) throws Exception;
	
	Customer getCustomerDetails(int id);
	
	List<Property> getAllProperties(String token) throws Exception;
	
	void assignRequirements(int custid, int reqid);
	
	boolean checkIfCustomerAlreadyExists(String customerName);
}
