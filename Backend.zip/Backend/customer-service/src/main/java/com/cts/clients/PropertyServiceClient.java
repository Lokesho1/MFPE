package com.cts.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.entities.Property;

@FeignClient(name = "property-service", url = "http://localhost:8090/property")
public interface PropertyServiceClient {

	@GetMapping("/getAllProperties")
	List<Property> getAllProperties(@RequestHeader(value = "Authorization", required = true) String token) throws Exception;

}
