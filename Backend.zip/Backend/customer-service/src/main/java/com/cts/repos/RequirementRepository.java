package com.cts.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entities.Requirement;

public interface RequirementRepository extends JpaRepository<Requirement, Integer> {

}
