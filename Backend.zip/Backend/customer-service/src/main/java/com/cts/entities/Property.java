package com.cts.entities;

import lombok.Data;

@Data
public class Property {

	private int id;
	private String propertyType;
	private String locality;
	private double budget;
}
