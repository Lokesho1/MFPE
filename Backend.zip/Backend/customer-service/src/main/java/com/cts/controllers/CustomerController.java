package com.cts.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cts.clients.AuthorizationClient;
import com.cts.entities.Customer;
import com.cts.entities.Property;
import com.cts.entities.Requirement;
import com.cts.exceptions.AuthorizationException;
import com.cts.exceptions.CustomerNotFoundException;
import com.cts.services.CustomerService;

@RestController
@CrossOrigin
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private AuthorizationClient authorizationClient;

	@GetMapping("/getAllRequirements")
	public ResponseEntity<List<Requirement>> getAllRequirements() throws AuthorizationException {
		return ResponseEntity.ok(customerService.getAllRequirements());
	}

	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers(@RequestHeader("Authorization") String token) {
		return ResponseEntity.ok(customerService.getAllCustomers());
	}

	@PostMapping("/createCustomer")
	public ResponseEntity<String> createCustomer(@RequestBody @Valid Customer customer) throws Exception {
		customerService.createCustomer(customer);
		return new ResponseEntity<>("Customer Created Successfully!", HttpStatus.CREATED);
	}

	@GetMapping("/getCustomerDetails/{id}")
	public ResponseEntity<Customer> getCustomerDetails(@RequestHeader("Authorization") String token,@PathVariable int id) throws Exception {
		Customer customer = customerService.getCustomerDetails(id);
		if (customer == null) {
			throw new CustomerNotFoundException("Customer Not Found!");
		}
			return ResponseEntity.ok(customer);
	}

	@GetMapping("/getProperties")
	public ResponseEntity<List<Property>> getAllProperties(@RequestHeader("Authorization") String token) throws Exception {
		System.out.println(token);
			return ResponseEntity.ok(customerService.getAllProperties(token));
	}

	@PutMapping("/{customerId}/assignRequirements/{requirementId}")
	public ResponseEntity<String> assignRequirements(@PathVariable("customerId") int custid, @PathVariable("requirementId") int reqid)
			throws AuthorizationException {
			customerService.assignRequirements(custid, reqid);
			return new ResponseEntity<>("Requirement Assigned Successfully!", HttpStatus.OK);
	}
}
