insert into requirement(property_type,locality,budget) values('villa','Hyderabad',1000000);
insert into requirement(property_type,locality,budget) values('flat','Mumbai',1500000);
insert into requirement(property_type,locality,budget) values('duplex','Delhi',2000000);