package cts.mfpe.authorization.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cts.controller.JwtAuthenticationController;
import com.cts.entity.User;
import com.cts.exception.UserAlredyExistsException;
import com.cts.service.JwtUserDetailsService;
import com.cts.util.JwtTokenUtil;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class ControllerTest {

	private final String requestTokenHeader = "vdgekncr4uliu45otu4864hutigh";
	@Autowired
	private MockMvc mvc;
	@InjectMocks
	JwtAuthenticationController authenticationController;

	@Mock
	JwtUserDetailsService service;

	@Mock
	JwtTokenUtil jwtUtil;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	private User mockUser() {
		User u = new User();
		u.setId(1);
		u.setUsername("UserName");
		u.setPassword("Password");
		return u;
	}

	private User mockUser2() {
		User u = new User();
		u.setId(1);
		u.setUsername("UserName1");
		u.setPassword("Password1");
		return u;
	}

	@Test
	void registerTest() throws Exception {
		User mockUser = mockUser();
		assertEquals(HttpStatus.CREATED, authenticationController.saveUser(mockUser).getStatusCode());

	}

//	@Test
//	void authorizeTheRequestTest() {
//        mvc.perform(MockMvcRequestBuilders.get("/test")).andExpect(status().isForbidden());
//
//	}

	@Test
	public void existentUserCanGetTokenAndAuthentication() throws Exception {
		String userName = "existentuser";
	    String password = "password";
	
	    String body = "{\"username\":\"" + userName + "\", \"password\":\"" + password + "\"}";	
	    mvc.perform(MockMvcRequestBuilders.post("/authenticate")
	            .content(body))
	            .andExpect(status().isOk());
	    
//	    String response = result.getResponse().getContentAsString();
//	    response = response.replace("{\"access_token\": \"", "");
//	    String token = response.replace("\"}", "");
//	
//	    mvc.perform(MockMvcRequestBuilders.post("/authorize")
//	        .header("Authorization", "Bearer " + token))
//	        .andExpect(status().isOk());
	}

}
