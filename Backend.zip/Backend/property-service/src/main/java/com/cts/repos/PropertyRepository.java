package com.cts.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entities.Property;

public interface PropertyRepository extends JpaRepository<Property, Integer> {

	List<Property> findByPropertyType(String propertyType);
	
	List<Property> findByLocality(String locality);
}
