package com.cts.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cts.clients.AuthorizationClient;
import com.cts.entities.Property;
import com.cts.exceptions.AuthorizationException;
import com.cts.exceptions.PropertyNotFoundException;
import com.cts.service.PropertyService;

@RestController
@CrossOrigin
public class PropertyController {

	@Autowired
	private PropertyService propertyService;

	@Autowired
	private AuthorizationClient authorizationClient;

	@PostMapping("/createProperty")
	public ResponseEntity<String> createProperty(@RequestBody @Valid Property property){
			propertyService.createProperty(property);
			return new ResponseEntity<>("Property Created Successfully!", HttpStatus.CREATED);
	}

	@GetMapping("/getAllProperties")
	public ResponseEntity<List<Property>> getAllProperties(@RequestHeader("Authorization") String token){
			return ResponseEntity.ok(propertyService.getAllProperties());
	}

	@GetMapping("/getAllPropertiesByType/{propertyType}")
	public ResponseEntity<List<Property>> getAllPropertiesByType(@PathVariable String propertyType) throws Exception {
		List<Property> properties = propertyService.getAllPropertiesByType(propertyType);
		if (properties.size() == 0) {
			throw new PropertyNotFoundException("Properties of property type " + propertyType + " Not Found!");
		}
			return ResponseEntity.ok(properties);
	}

	@GetMapping("/getAllPropertiesByLocality/{locality}")
	public ResponseEntity<List<Property>> getAllPropertiesByLocality(@PathVariable String locality)throws Exception {
		List<Property> properties = propertyService.getAllPropertiesByLocality(locality);
		if (properties.size() == 0) {
			throw new PropertyNotFoundException("Properties in locality " + locality + " Not Found!");
		}
			return ResponseEntity.ok(properties);
	}
}
