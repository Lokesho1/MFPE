package com.cts.exceptions;

public class ExecutiveNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public ExecutiveNotFoundException(String message) {
		super(message);
	}
}
