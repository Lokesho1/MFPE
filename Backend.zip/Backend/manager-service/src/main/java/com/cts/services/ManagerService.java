package com.cts.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.entities.Customer;
import com.cts.entities.Executive;

@Service
public interface ManagerService {

	public void createExecutive(Executive executive) throws Exception;
	
	public Executive getExecutiveDetails(int id) throws Exception;
	
	public List<Executive> getAllExecutives();
	
	public List<Executive> getAllExecutivesByLocality(String locality) throws Exception;
	
	public List<Customer> getAllCustomers(String token);
	
	public Customer getCustomerById(String token,int id) throws Exception;
	
	public void assignExecutive(int executiveid, int customerid, String token) throws Exception;
}
