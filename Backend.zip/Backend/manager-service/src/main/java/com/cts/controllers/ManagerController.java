package com.cts.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cts.clients.AuthorizationClient;
import com.cts.entities.Customer;
import com.cts.entities.Executive;
import com.cts.exceptions.AuthorizationException;
import com.cts.exceptions.CustomerNotFoundException;
import com.cts.exceptions.ExecutiveNotFoundException;
import com.cts.services.ManagerService;

@RestController
@CrossOrigin
public class ManagerController {

	@Autowired
	private ManagerService executiveService;

	@Autowired
	private AuthorizationClient authorizationClient;

	@PostMapping("/createExecutive")
	public ResponseEntity<String> createExecutive(@RequestBody @Valid Executive executive) throws Exception {
		executiveService.createExecutive(executive);
		return new ResponseEntity<String>("Executive Created Successfully!", HttpStatus.CREATED);

	}

	@GetMapping("/getExecutiveDetails/{id}")
	public ResponseEntity<Executive> getExecutiveDetails(@PathVariable int id) throws Exception {
		Executive executive = executiveService.getExecutiveDetails(id);
		if (executive == null) {
			throw new CustomerNotFoundException("Executive with id " + id + " not found");
		}
		return ResponseEntity.ok(executive);
	}

	@GetMapping("/getAllExecutives")
	public ResponseEntity<List<Executive>> getAllExecutives() throws AuthorizationException {
			return ResponseEntity.ok(executiveService.getAllExecutives());
	}

	@GetMapping("/getAllExecutivesByLocality/{locality}")
	public ResponseEntity<List<Executive>> getAllExecutivesByLocality(@PathVariable String locality) throws Exception {
		List<Executive> executives = executiveService.getAllExecutivesByLocality(locality);
		if (executives.size() == 0) {
			throw new ExecutiveNotFoundException("Executives in locality " + locality + " not found");
		}
			return ResponseEntity.ok(executives);
	}

	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers(@RequestHeader("Authorization") String token) throws Exception {
		return ResponseEntity.ok(executiveService.getAllCustomers(token));
	}

	@GetMapping("/getCustomersById/{id}")
	public ResponseEntity<Customer> getCustomerById(@RequestHeader("Authorization") String token,@PathVariable int id) throws Exception {
		Customer customer = executiveService.getCustomerById(token,id);
		if (customer == null) {
			throw new CustomerNotFoundException("Customer with id " + id + " not found");
		}
			return ResponseEntity.ok(customer);
	}

	@PutMapping("/{executiveId}/assignExecutive/{customerId}")
	public ResponseEntity<String> assignExecutive(@RequestHeader("Authorization") String token,@PathVariable("executiveId") int execid,
			@PathVariable("customerId") int custid) throws Exception {
			executiveService.assignExecutive(execid, custid,token);
			return new ResponseEntity<>("Executive Assigned Successfully!", HttpStatus.OK);
	}
}
