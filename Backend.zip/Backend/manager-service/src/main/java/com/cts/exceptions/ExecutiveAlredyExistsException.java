package com.cts.exceptions;

public class ExecutiveAlredyExistsException extends Exception{

	private static final long serialVersionUID = 1L;

	public ExecutiveAlredyExistsException(String message) {
		super(message);
	}
}
